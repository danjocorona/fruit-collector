import pygame
from game.fruit import Fruit
from game.bomb import Bomb

class Spawner:
    def __init__(self, screen_width, screen_height):
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.fruits = []
        self.bombs = []

    def spawn_fruit(self):
        self.fruits.append(Fruit(self.screen_width))

    def spawn_bomb(self):
        self.bombs.append(Bomb(self.screen_width))

    def update(self):
        for fruit in self.fruits:
            fruit.update()
        for bomb in self.bombs:
            bomb.update()

        # Remove fruits that fall off the screen
        self.fruits = [f for f in self.fruits if not f.off_screen(self.screen_height)]
        self.bombs = [b for b in self.bombs if not b.off_screen(self.screen_height)]

    def draw(self, screen):
        for fruit in self.fruits:
            fruit.draw(screen)
        for bomb in self.bombs:
            bomb.draw(screen)

    def get_fruits(self):
        return self.fruits
    
    def get_bombs(self):
        return self.bombs