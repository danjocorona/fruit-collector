import pygame
import random
import os

class Bomb:
    def __init__(self, screen_width):
        self.image = pygame.image.load(os.path.join("assets", "images", "bomb.png")).convert()
        self.image.set_colorkey((0, 0, 0))  # make black transparent
        self.image = pygame.transform.scale(self.image, (40, 40))
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, screen_width - self.rect.width)
        self.rect.y = -self.rect.height
        self.speed = random.randint(4,7)

    def update(self):
        self.rect.y += self.speed

    def draw(self, screen):
        screen.blit(self.image, self.rect)

    def off_screen(self, screen_height):
        return self.rect.top > screen_height