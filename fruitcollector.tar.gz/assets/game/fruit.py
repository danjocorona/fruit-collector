import pygame
import random
import os

class Fruit:
    def __init__(self, screen_width):
        fruit_files = [
            "Apple.png",
            "Bannna.png",
            "Cheries.png",
            "Grapes Blue.png",
            "Grapes Green.png",
            "Orange.png",
            "Pear.png"
        ]
        MAX_WIDTH = 32
        MAX_HEIGHT = 32

        fruit_file = random.choice(fruit_files)
        self.image = pygame.image.load(os.path.join("assets", "images", fruit_file))
        self.image = pygame.transform.scale(self.image, (MAX_WIDTH, MAX_HEIGHT))
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, screen_width - self.rect.width)
        self.rect.y = -self.rect.height
        self.speed = random.randint(3, 6)

    def update(self):
        self.rect.y += self.speed

    def draw(self, screen):
        screen.blit(self.image, self.rect)

    def off_screen(self, screen_height):
        return self.rect.top > screen_height