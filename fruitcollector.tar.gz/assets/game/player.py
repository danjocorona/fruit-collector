import pygame
import os

class Player:
    def __init__(self, screen_width, screen_height):
        self.image = pygame.image.load(os.path.join("assets", "images", "basket.png"))
        self.rect = self.image.get_rect()
        self.rect.centerx = screen_width // 2
        self.rect.bottom = screen_height - 10
        self.speed = 6

    def move(self, keys, screen_width):
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < screen_width:
            self.rect.x += self.speed

    def draw(self, screen):
        screen.blit(self.image, self.rect)