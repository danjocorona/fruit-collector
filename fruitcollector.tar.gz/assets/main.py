import pygame
from game.player import Player
from game.spawner import Spawner

# Initialize Pygame
pygame.init()

# Screen settings
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Fruit Collector")

# Clock
clock = pygame.time.Clock()
FPS = 60

# Score
score = 1
game_over = False
game_won = False
game_started = False
font = pygame.font.Font(None, 36)

# Create player
player = Player(WIDTH, HEIGHT)
spawner = Spawner(WIDTH, HEIGHT)

SPAWN_FRUIT_EVENT = pygame.USEREVENT + 1
pygame.time.set_timer(SPAWN_FRUIT_EVENT, 1500)
SPAWN_BOMB_EVENT = pygame.USEREVENT + 2
pygame.time.set_timer(SPAWN_BOMB_EVENT, 2200)

def reset_game():
    global score, game_over, game_won, game_started, spawner, player

    score = 1
    game_over = False
    game_won = False
    game_started = False

    player = Player(WIDTH, HEIGHT)
    spawner = Spawner(WIDTH, HEIGHT)

    pygame.time.set_timer(SPAWN_FRUIT_EVENT, 1500)
    pygame.time.set_timer(SPAWN_BOMB_EVENT, 2200)

# Main loop
running = True
while running:
    clock.tick(FPS)

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif not game_started and event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            game_started = True

        elif event.type == SPAWN_FRUIT_EVENT and game_started and not (game_over or game_won):
            spawner.spawn_fruit()

        elif event.type == SPAWN_BOMB_EVENT and game_started and not (game_over or game_won):
            spawner.spawn_bomb()
        
        elif (game_over or game_won) and event.type == pygame.KEYDOWN and event.key == pygame.K_r:
            reset_game()

    # Update game logic
    if game_started and not (game_over or game_won):
        keys = pygame.key.get_pressed()
        player.move(keys, WIDTH)
        spawner.update()

        # Fruit collisions
        for fruit in spawner.get_fruits()[:]:
            if player.rect.colliderect(fruit.rect):
                spawner.get_fruits().remove(fruit)
                score += 1

        # Bomb collisions
        for bomb in spawner.get_bombs()[:]:
            if player.rect.colliderect(bomb.rect):
                spawner.get_bombs().remove(bomb)
                score -= 10

        # Win/Lose conditions
        if score <= 0:
            game_over = True
            pygame.time.set_timer(SPAWN_FRUIT_EVENT, 0)
            pygame.time.set_timer(SPAWN_BOMB_EVENT, 0)

        if score >= 50:
            game_won = True
            pygame.time.set_timer(SPAWN_FRUIT_EVENT, 0)
            pygame.time.set_timer(SPAWN_BOMB_EVENT, 0)

    # Draw everything
    screen.fill((255, 255, 255))

    if game_started:
        spawner.draw(screen)
        player.draw(screen)

        # Score display
        score_text = font.render(f"Score: {score}", True, (0, 0, 0))
        screen.blit(score_text, (10, 10))

    # Start screen
    if not game_started:
        title_font = pygame.font.Font(None, 72)
        title_text = title_font.render("Fruit Collector", True, (0, 0, 0))
        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 2 - 50))

        prompt_font = pygame.font.Font(None, 36)
        prompt_text = prompt_font.render("Press SPACE to Start", True, (0, 0, 0))
        screen.blit(prompt_text, (WIDTH // 2 - prompt_text.get_width() // 2, HEIGHT // 2 + 20))

    # Game over screen
    if game_over:
        game_over_font = pygame.font.Font(None, 72)
        game_over_text = game_over_font.render("GAME OVER", True, (255, 0, 0))
        screen.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 2))

        restart_text = font.render("Press R to Restart", True, (0, 0, 0))
        screen.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, HEIGHT // 2 + 50))

    # Win screen
    elif game_won:
        win_font = pygame.font.Font(None, 72)
        win_text = win_font.render("YOU WIN!", True, (0, 128, 0))
        screen.blit(win_text, (WIDTH // 2 - win_text.get_width() // 2, HEIGHT // 2))

        restart_text = font.render("Press R to Restart", True, (0, 0, 0))
        screen.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, HEIGHT // 2 + 50))

    pygame.display.flip()

pygame.quit()