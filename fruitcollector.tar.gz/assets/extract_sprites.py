import pygame
import os

# Initialize pygame
pygame.init()

# Load full sprite sheets
basket_sheet = pygame.image.load("assets/images/basket_sheet.png")
bomb_sheet = pygame.image.load("assets/images/bomb_sheet.png")

# Extract a single basket (adjust x, y, width, height as needed)
basket = basket_sheet.subsurface(pygame.Rect(0, 0, 64, 64))

# Extract a single bomb
bomb = bomb_sheet.subsurface(pygame.Rect(0, 0, 20, 26))

# Save the extracted images
pygame.image.save(basket, "assets/images/basket.png")
pygame.image.save(bomb, "assets/images/bomb.png")

print("Sprites extracted and saved!")
pygame.quit()